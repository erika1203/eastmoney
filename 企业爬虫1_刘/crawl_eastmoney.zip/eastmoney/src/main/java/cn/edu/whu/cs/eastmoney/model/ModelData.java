package cn.edu.whu.cs.eastmoney.model;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;

import cn.edu.whu.cs.eastmoney.util.SpiderUtils;
/**
 * 获取企业评估需要的所有数据
 * @author hegongshan https://www.hegongshan.com
 *
 */
public class ModelData {
	private static SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
	private static SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
	
	//获取企业评估需要的所有数据．
	public static JSONArray getData(String code) throws IOException, ParseException {
		return getData(code,null);
	}
	
	public static JSONArray getData(String code,InetSocketAddress proxy) throws IOException, ParseException {
		//获取公司名称和当前股票价格
		String name;
		String stockPrice;
		Document doc;
		if(null == proxy) {
			doc = Jsoup.parse(SpiderUtils.gets("http://emweb.securities.eastmoney.com/NewFinanceAnalysis/Index?type=web&code="+code));
		} else {
			doc = Jsoup.parse(SpiderUtils.getsByProxy("http://emweb.securities.eastmoney.com/NewFinanceAnalysis/Index?type=web&code="+code,proxy));
		}
		name = doc.select("#hq_1").text();
		stockPrice = doc.select("#hq_2").text();
		
		JSONArray zcfzData = getZcfz(code,proxy);
		JSONArray profitData = getProfit(code,proxy);
		JSONArray percentData = getPercent(code,proxy);
		JSONArray zgbData = getZgb(code,proxy);
		JSONArray dubangData = getDubang(code,proxy);
		JSONArray dataArray = new JSONArray();
		
		for (int i = 0; i < zcfzData.size(); i++) {
			JSONObject zcfzJson = (JSONObject)zcfzData.get(i);
			JSONObject profitJson = (JSONObject)profitData.get(i);
			JSONObject percentJson = (JSONObject)percentData.get(i);
			JSONObject dubangJson = (JSONObject)dubangData.get(i);
			JSONObject data = new JSONObject();
			data.put("公司名称", name);
			data.put("公司代码", code);
			
			String reportDate = dateFormat.format(sdf.parse(zcfzJson.getString("REPORTDATE")));
			data.put("报告期", reportDate);
			data.put("流动资产", zcfzJson.getString("SUMLASSET"));
			data.put("流动负债",zcfzJson.getString("SUMLLIAB"));	
			data.put("总资产", zcfzJson.getString("SUMASSET"));
			data.put("总负债", zcfzJson.getString("SUMLIAB"));
			data.put("未分配利润", zcfzJson.getString("RETAINEDEARNING"));
			data.put("盈余公积金",zcfzJson.getString("SURPLUSRESERVE"));
			data.put("利润总额", profitJson.getString("SUMPROFIT"));
			data.put("总股本", matchZgb(reportDate,zgbData));
			
			//由于只能获取到当前股票价格，所以，其他的股票价格全标为0
			if(i == 0) {
				data.put("股票价格", stockPrice);
			} else {
				data.put("股票价格", 0);
			}
			
			data.put("营业收入", profitJson.getString("OPERATEREVE"));
			data.put("固定资产", zcfzJson.getString("FIXEDASSET"));
			data.put("递延所得税资产", zcfzJson.getString("DEFERINCOMETAXASSET"));
			data.put("股东权益", zcfzJson.getString("SUMSHEQUITY"));
			data.put("无形资产", zcfzJson.getString("INTANGIBLEASSET"));
			data.put("净利润", profitJson.getString("NETPROFIT"));
			data.put("负债总计", zcfzJson.getString("SUMLIAB"));
			data.put("资产总计", zcfzJson.getString("SUMASSET"));
			data.put("应付利息", zcfzJson.getString("INTERESTPAY"));
			data.put("存货", zcfzJson.getString("INVENTORY"));
			data.put("销售费用", parseXsfy(percentJson.getString("xsfy")));
			data.put("营业税金及附加",profitJson.getString("OPERATETAX"));
			data.put("财务费用",profitJson.getString("FINANCEEXP"));
			data.put("应收账款", zcfzJson.getString("ACCOUNTREC"));
			data.put("实收资本（或股本）", zcfzJson.getString("SHARECAPITAL"));
			data.put("资本公积", zcfzJson.getString("CAPITALRESERVE"));
			data.put("杜邦分析",dubangJson.getString("jzcsyl"));
			dataArray.add(data);
		}
		return dataArray;
	}
	//转换销售费用
	private static String parseXsfy(String xsfy) {
		if(xsfy.endsWith("万")) {
			return new Double(Double.parseDouble(xsfy.substring(0,xsfy.length()-1)) * 10000).toString();
		} else if(xsfy.endsWith("亿")) {
			return new Double(Double.parseDouble(xsfy.substring(0,xsfy.length()-1)) * 100000000).toString();
		} else {
			return xsfy;
		}
	}
	
	//资产负债表
	private static JSONArray getZcfz(String code,InetSocketAddress proxy) throws IOException {
		return extractJSONArray("http://emweb.securities.eastmoney.com/NewFinanceAnalysis/zcfzbAjax?companyType=4&reportDateType=0&reportType=1&endDate=&code="+code,proxy);
	}
	
	//利润表
	private static JSONArray getProfit(String code,InetSocketAddress proxy) throws IOException {
		return  extractJSONArray("http://emweb.securities.eastmoney.com/NewFinanceAnalysis/lrbAjax?companyType=4&reportDateType=0&reportType=1&endDate=&code="+code,proxy);
	}
	
	//百分比表
	private static JSONArray getPercent(String code,InetSocketAddress proxy) throws IOException {
		JSONObject percentData = getJSON("http://emweb.securities.eastmoney.com/NewFinanceAnalysis/PercentAjax?code="+code+"&ctype=4&type=0",proxy);
		JSONObject result = (JSONObject) percentData.get("Result");
		return (JSONArray)result.get("lr0");
	}

	//杜邦分析表
	private static JSONArray getDubang(String code, InetSocketAddress proxy) throws IOException {
		JSONObject dubangData = getJSON("http://emweb.securities.eastmoney.com/NewFinanceAnalysis/DubangAnalysisAjax?code="+code,proxy);
		JSONArray result = (JSONArray) dubangData.get("bgq");
		return result;
	}

	//总股本
	private static JSONArray getZgb(String code,InetSocketAddress proxy) throws IOException {
		JSONArray jsonArray = new JSONArray();
		JSONObject stockStructureData = getJSON("http://emweb.securities.eastmoney.com/PC_HSF10/CapitalStockStructure/CapitalStockStructureAjax?code="+code,proxy);
		JSONObject result = (JSONObject) stockStructureData.get("Result");
		
		/*JSONObject stockDetail = (JSONObject)result.get("CapitalStockStructureDetail");
		//当前总股本(万股)
		System.out.println(stockDetail.getDoubleValue("zgb"));*/
		
		//历史总股本(万股)
		JSONArray tempArr = (JSONArray)result.get("ShareChangeList");
		String zgbStr = null;
		String timeStr = null;
		for (int i = 0; i < tempArr.size(); i++) {
			JSONObject zgbData = ((JSONObject)tempArr.get(i));
			String des = zgbData.getString("des");
			if(des.contains("单位:万股")) {
				timeStr = zgbData.getString("changeList");
			}
			if(des.contains("总股本")) {
				zgbStr = zgbData.getString("changeList");
			}
		}
		timeStr = timeStr.substring(2, zgbStr.length()-2).replace("\",\"", " ");
		zgbStr = zgbStr.substring(2, zgbStr.length()-2).replace("\",\"", " ");
		String[] zgbs = zgbStr.split(" ");
		String[] times = timeStr.split(" ");
		for (int i = 0; i < times.length; i++) {
			//去除形如＂2011-0＂等不完整数据
			if(times[i].length()<10) {
				continue;
			}
			JSONObject json = new JSONObject();
			json.put("时间", times[i]);
			json.put("总股本", Double.parseDouble(zgbs[i].replace(",", "")));
			jsonArray.add(json);
		}
		return jsonArray;
	}
	//根据报告期，从总股本数组中匹配相应的总股本
	private static double matchZgb(String reportDate,JSONArray zgbData) {
		for (int j = 0; j < zgbData.size(); j++) {
			JSONObject zgbJson = (JSONObject)zgbData.get(j);
			//总股本时间和报告期完全相同
			if(reportDate.equals(zgbJson.getString("时间"))) {
				return zgbJson.getDouble("总股本");
			}
		}
		for (int j = 0; j < zgbData.size(); j++) {
			JSONObject zgbJson = (JSONObject)zgbData.get(j);
			//总股本时间和报告期不能完全匹配,但存在同年同月
			if(reportDate.substring(0,7).equals(zgbJson.getString("时间").substring(0,7))) {
				return zgbJson.getDouble("总股本");
			}
		}
		for (int j = zgbData.size()-1; j >= 0; j--) {
			JSONObject zgbJson = (JSONObject)zgbData.get(j);
			//总股本时间和报告期不能完全匹配,且不存在同年同月,但存在同年的数据,取同年较小月份的总股本
			if(reportDate.substring(0,4).equals(zgbJson.getString("时间").substring(0,4))) {
				return zgbJson.getDouble("总股本");
			}
		}
		return 0;
	}
	
	//获取返回的json数据
	private static JSONObject getJSON(String url,InetSocketAddress proxy) throws IOException {
		if(null == proxy) {
			return JSONObject.parseObject(SpiderUtils.get(url).text());
		}
		return JSONObject.parseObject(SpiderUtils.getByProxy(url, proxy.getHostName(), proxy.getPort()).text());
	}
	
	//从返回的不规则字符串中提取json数组
	private static JSONArray extractJSONArray(String url,InetSocketAddress proxy) throws IOException {
		Document doc;
		if(null == proxy) {
			doc = SpiderUtils.get(url);
		} else {
			doc = SpiderUtils.getByProxy(url, proxy.getHostName(), proxy.getPort());
		}
		String str = doc.text().replace("\\\"", "\"");
		String jsonStr = str.substring(1,str.length()-1);
		return JSONArray.parseArray(jsonStr);
	}
	
	/*public static void main(String[] args) throws IOException, ParseException {
		System.out.println(getData("SZ000988"));
	}*/
}
