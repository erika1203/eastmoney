package cn.edu.whu.cs.eastmoney.util;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.Charset;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;

import com.gargoylesoftware.htmlunit.FailingHttpStatusCodeException;
import com.gargoylesoftware.htmlunit.NicelyResynchronizingAjaxController;
import com.gargoylesoftware.htmlunit.WebClient;
import com.gargoylesoftware.htmlunit.WebClientOptions;
import com.gargoylesoftware.htmlunit.WebRequest;
import com.gargoylesoftware.htmlunit.html.HtmlPage;

/**
 * 爬虫工具类
 * @author hegongshan　https://www.hegongshan.com
 *
 */
public class SpiderUtils {
	private static String USER_AGENT = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.75 Safari/537.36";

	public static Document get(String url) throws IOException {
		return Jsoup.connect(url)
				.userAgent(USER_AGENT)
				.ignoreContentType(true)
				.get();
	}
	
	public static Document getByProxy(String url,String host,int port) throws IOException {
		return Jsoup.connect(url)
				.userAgent(USER_AGENT)
				.proxy(host, port)
				.ignoreContentType(true)
				.get();
	}
	
	//针对某些无法找到ajax请求但需要加载才能显示的数据
	public static String gets(String url) throws FailingHttpStatusCodeException, MalformedURLException, IOException {
		org.apache.log4j.Logger.getLogger("com.gargoylesoftware.htmlunit").setLevel(org.apache.log4j.Level.FATAL);
		java.util.logging.Logger.getLogger("com.gargoylesoftware.htmlunit").setLevel(java.util.logging.Level.SEVERE);
		
		WebClient client = new WebClient();
		WebRequest request = new WebRequest(new URL(url),"get");
		request.setCharset(Charset.forName("utf-8"));
		request.setAdditionalHeader("User-Agent",USER_AGENT);
		WebClientOptions options = client.getOptions();
		options.setCssEnabled(false);
		options.setJavaScriptEnabled(true);
		options.setTimeout(30000);
		options.setRedirectEnabled(false);
		
		options.setThrowExceptionOnFailingStatusCode(false);
		options.setThrowExceptionOnScriptError(false);
		
		client.waitForBackgroundJavaScriptStartingBefore(5000);
		client.waitForBackgroundJavaScript(10000);
		client.setAjaxController(new NicelyResynchronizingAjaxController());
		HtmlPage page = null;
		try{
			page = client.getPage(request);
		} catch(java.net.ConnectException e) {
		}
		String html = page.asXml();
		client.close();
		return html;
	}
	
	public static String getsByProxy(String url,InetSocketAddress proxy) throws FailingHttpStatusCodeException, MalformedURLException, IOException {
		org.apache.log4j.Logger.getLogger("com.gargoylesoftware.htmlunit").setLevel(org.apache.log4j.Level.FATAL);
		java.util.logging.Logger.getLogger("com.gargoylesoftware.htmlunit").setLevel(java.util.logging.Level.SEVERE);
		
		WebClient client = new WebClient();
		WebRequest request = new WebRequest(new URL(url),"get");
		request.setCharset(Charset.forName("utf-8"));
		request.setAdditionalHeader("User-Agent",USER_AGENT);
		request.setProxyHost(proxy.getHostName());
		request.setProxyPort(proxy.getPort());
		WebClientOptions options = client.getOptions();
		options.setCssEnabled(false);
		options.setJavaScriptEnabled(true);
		options.setTimeout(30000);
		options.setRedirectEnabled(false);
		
		options.setThrowExceptionOnFailingStatusCode(false);
		options.setThrowExceptionOnScriptError(false);
		
		client.waitForBackgroundJavaScriptStartingBefore(5000);
		client.waitForBackgroundJavaScript(10000);
		client.setAjaxController(new NicelyResynchronizingAjaxController());
		HtmlPage page = null;
		try{
			page = client.getPage(request);
		} catch(java.net.ConnectException e) {
		}
		String html = page.asXml();
		client.close();
		return html;
	}
}
