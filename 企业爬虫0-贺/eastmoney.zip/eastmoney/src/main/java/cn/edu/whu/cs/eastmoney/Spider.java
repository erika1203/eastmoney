package cn.edu.whu.cs.eastmoney;

import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import org.json.JSONException;
import org.jsoup.nodes.Document;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;

import cn.edu.whu.cs.eastmoney.model.ModelData;
import cn.edu.whu.cs.eastmoney.util.CSVUtils;
import cn.edu.whu.cs.eastmoney.util.SpiderUtils;
/**
 * 东方财富网爬虫
 * @author hegongshan https://www.hegongshan.com
 *
 */
public class Spider {

	public static Logger logger = LoggerFactory.getLogger(Spider.class);

	/**
	 * 获取＂新材料＂前20页中公司的＂代码＂，若需要＂东方财富网＂全部企业的＂代码＂，
	 * 请重写该方法以得到其他模块下公司的代码
	 * @return
	 * @throws IOException
	 */
	public static List<String> getCodes() throws IOException {
		List<String> list = new ArrayList<>();
		for (int i = 0; i < 20; i++) {
			Document doc = SpiderUtils.get(
					"http://nufm.dfcfw.com/EM_Finance2014NumericApplication/JS.aspx?cb=jQuery11240514290509665662_1535437304354&type=CT&token=4f1862fc3b5e77c150a2b985b12db0fd&sty=FCOIATC&js=(%7Bdata%3A%5B(x)%5D%2CrecordsFiltered%3A(tot)%7D)&cmd=C.BK05231&st=(ChangePercent)&sr=-1&p="
							+ (i + 1) + "&ps=20&_=1535437304361");
			String responseString = doc.text();
			JSONObject jsonObj = JSONObject.parseObject(responseString
					.substring("jQuery11240514290509665662_1535437304354(".length(), responseString.length() - 1));
			JSONArray jsonArr = (JSONArray) jsonObj.get("data");
			for (int j = 0; j < jsonArr.size(); j++) {
				String[] sArr = jsonArr.get(j).toString().split(",");
				String code = null;
				if (Integer.parseInt(sArr[0]) == 1) {
					code = "SH" + sArr[1];
				} else if (Integer.parseInt(sArr[0]) == 2) {
					code = "SZ" + sArr[1];
				} else {
					break;
				}
				if (!list.contains(code)) {
					list.add(code);
				}
			}
		}
		return list;
	}
	//根据公司代码，将需要的模型数据写入到指定的csv文件中
	public static void storeData(String code,String filePath) throws JSONException, IOException, ParseException {
		CSVUtils.writeCSV(ModelData.getData(code), filePath);
	}
	
	public static void main(String[] args) throws IOException, JSONException, ParseException {
		List<String> codes = getCodes();
		for (String code : codes) {
			storeData(code,"src/main/resources/eastmoney.csv");
		}
	}
}
