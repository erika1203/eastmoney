package cn.edu.whu.cs.eastmoney.util;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.json.CDL;
import org.json.JSONException;

import com.alibaba.fastjson.JSONArray;

/**
 * json数组 转 csv文件
 * @author hegongshan　https://www.hegongshan.com
 *
 */
public class CSVUtils {
	
	/**
	 * 将一个json数组写入到指定的文件中
	 * @param dataArray
	 * @param filePath
	 * @throws JSONException
	 * @throws IOException
	 */
	public static void writeCSV(JSONArray dataArray,String filePath) throws JSONException, IOException {
		FileUtils.writeStringToFile(new File(filePath),CDL.toString(new org.json.JSONArray(dataArray.toString())),"utf-8",true);
	}

}
